# Pokémon Card Scanner — prototipo gratuito

## Qué incluye
- Diseño adaptable a móvil y ordenador.
- Vista previa de una foto desde la cámara o la galería.
- Búsqueda de cartas en Pokémon TCG API.
- Referencias de precio EUR (Cardmarket) y USD (TCGplayer) cuando los datos existen en el registro.
- PWA básica para instalar desde el navegador cuando se aloje con HTTPS.

## Limitaciones actuales
- **No identifica automáticamente una carta a partir de la foto.** La foto es una vista previa; se busca por nombre. El reconocimiento visual es una siguiente fase.
- Los precios son los campos disponibles en el catálogo y pueden faltar o estar desactualizados. No se garantiza acceso permanente a fuentes de precios.
- La API y sus políticas/límites pueden cambiar. Revisa https://pokemontcg.io/ antes de un lanzamiento público.
- No se debe presentar como tasación oficial. La condición, idioma, edición y variante afectan al precio.

## Cómo probarlo en tu ordenador
Como el navegador restringe algunas funciones al abrir archivos directamente, es mejor servirlo desde un servidor local. Si tienes Python instalado:
1. Descomprime el ZIP.
2. Abre una terminal dentro de la carpeta.
3. Ejecuta `python -m http.server 8000`
4. Abre `http://localhost:8000`.

## Cómo publicarlo gratis para probar con otros
1. Crea una cuenta en GitHub.
2. Crea un repositorio público nuevo.
3. Sube todos los archivos de esta carpeta a la raíz del repositorio.
4. En Settings → Pages, elige desplegar desde la rama `main` y la carpeta raíz.
5. Espera a que GitHub Pages te dé una URL HTTPS.
6. Abre esa URL en tu móvil. En Android, usa el menú del navegador → Instalar app/Añadir a pantalla de inicio. En iPhone, Safari → Compartir → Añadir a pantalla de inicio.

GitHub Pages puede alojar un sitio estático de forma gratuita para proyectos públicos, sujeto a sus condiciones y límites. No incluyas claves privadas ni datos personales en este repositorio.

## Siguiente fase recomendada
1. Identificación de carta por OCR (nombre y número).
2. Mostrar candidatos y pedir confirmación cuando haya varias ediciones.
3. Fuente autorizada de precios y fecha de actualización.
4. Guardar colección e historial (esto requerirá almacenamiento/backend si se sincroniza entre dispositivos).
