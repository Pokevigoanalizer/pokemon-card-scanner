const API = "https://api.pokemontcg.io/v2/cards";
const searchInput = document.getElementById("searchInput");
const searchBtn = document.getElementById("searchBtn");
const statusEl = document.getElementById("status");
const resultsEl = document.getElementById("results");
const moreBtn = document.getElementById("moreBtn");
const photoInput = document.getElementById("photoInput");
const previewWrap = document.getElementById("photoPreviewWrap");
const preview = document.getElementById("photoPreview");
const clearPhoto = document.getElementById("clearPhoto");
let currentQuery = "";
let page = 1;
let installPrompt = null;

function escapeHTML(value="") {
  return String(value).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
function money(value, currency) {
  if (value === undefined || value === null || value === "") return "No disponible";
  const n = Number(value);
  if (!Number.isFinite(n)) return "No disponible";
  return new Intl.NumberFormat("es-ES",{style:"currency",currency,maximumFractionDigits:2}).format(n);
}
function getPrices(card) {
  const p = card.tcgplayer?.prices || {};
  const candidates = ["market","mid","low"];
  let usd = null;
  for (const type of ["normal","holofoil","reverseHolofoil","1stEditionHolofoil","unlimitedHolofoil"]) {
    if (p[type]) {
      for (const key of candidates) if (p[type][key] != null) { usd = p[type][key]; break; }
      if (usd != null) break;
    }
  }
  const cm = card.cardmarket?.prices || {};
  const eur = cm.averageSellPrice ?? cm.trendPrice ?? cm.avg1 ?? cm.lowPrice;
  return {usd,eur};
}
function cardHTML(card) {
  const prices = getPrices(card);
  const image = card.images?.small || card.images?.large || "";
  const set = card.set?.name || "Colección desconocida";
  const number = card.number ? `${card.number}${card.set?.printedTotal ? " / " + card.set.printedTotal : ""}` : "";
  const safeName = escapeHTML(card.name || "Carta Pokémon");
  const safeSet = escapeHTML(set);
  const safeImage = escapeHTML(image);
  const usdLabel = prices.usd == null ? "No disponible" : money(prices.usd,"USD");
  const eurLabel = prices.eur == null ? "No disponible" : money(prices.eur,"EUR");
  return `<article class="card">
    <img src="${safeImage}" alt="${safeName}" loading="lazy" onerror="this.style.visibility='hidden'">
    <div><h3>${safeName}</h3><div class="meta">${safeSet}</div>
    <div class="setno">N.º ${escapeHTML(number || "—")} · ${escapeHTML(card.rarity || "Rareza no indicada")}</div>
    <div class="price eu">Europa <strong>${eurLabel}</strong></div>
    <div class="price">EE. UU. <strong>${usdLabel}</strong></div>
    <div class="setno">Referencia de API; no garantiza precio de venta.</div></div>
  </article>`;
}
async function searchCards(append=false) {
  const term = searchInput.value.trim();
  if (!term) {
    statusEl.textContent = "Escribe el nombre de una carta para buscarla.";
    searchInput.focus();
    return;
  }
  if (!append) {
    currentQuery = term;
    page = 1;
    resultsEl.innerHTML = "";
    moreBtn.classList.add("hidden");
  }
  statusEl.textContent = "Buscando cartas…";
  searchBtn.disabled = true;
  moreBtn.disabled = true;
  try {
    const q = encodeURIComponent(`name:"${currentQuery.replace(/["\\]/g,"")}*"`);
    const url = `${API}?q=${q}&page=${page}&pageSize=12&orderBy=-set.releaseDate`;
    const response = await fetch(url);
    if (!response.ok) throw new Error(`La API respondió ${response.status}`);
    const data = await response.json();
    if (!data.data?.length && !append) {
      statusEl.textContent = "No se encontraron cartas. Prueba otro nombre en inglés.";
      return;
    }
    resultsEl.insertAdjacentHTML("beforeend", (data.data || []).map(cardHTML).join(""));
    statusEl.textContent = `${resultsEl.children.length} resultado(s). Comprueba que la edición y el idioma coincidan con tu carta.`;
    if ((data.data || []).length === 12) moreBtn.classList.remove("hidden");
    else moreBtn.classList.add("hidden");
  } catch (err) {
    statusEl.textContent = "No se pudo consultar el catálogo. Comprueba tu conexión e inténtalo de nuevo. " + err.message;
  } finally {
    searchBtn.disabled = false;
    moreBtn.disabled = false;
  }
}
searchBtn.addEventListener("click", () => searchCards(false));
searchInput.addEventListener("keydown", e => { if (e.key === "Enter") searchCards(false); });
moreBtn.addEventListener("click", () => { page += 1; searchCards(true); });
photoInput.addEventListener("change", () => {
  const file = photoInput.files?.[0];
  if (!file) return;
  if (!file.type.startsWith("image/")) { statusEl.textContent = "Elige un archivo de imagen."; return; }
  preview.src = URL.createObjectURL(file);
  previewWrap.classList.remove("hidden");
  statusEl.textContent = "Foto cargada. La identificación automática por imagen aún no está conectada: escribe el nombre de la carta abajo para buscarla.";
});
clearPhoto.addEventListener("click", () => {
  photoInput.value = "";
  preview.removeAttribute("src");
  previewWrap.classList.add("hidden");
  statusEl.textContent = "Foto quitada.";
});
window.addEventListener("beforeinstallprompt", e => {
  e.preventDefault();
  installPrompt = e;
  document.getElementById("installBtn").classList.remove("hidden");
});
document.getElementById("installBtn").addEventListener("click", async () => {
  if (!installPrompt) return;
  installPrompt.prompt();
  await installPrompt.userChoice;
  installPrompt = null;
  document.getElementById("installBtn").classList.add("hidden");
});
if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
  window.addEventListener("load", () => navigator.serviceWorker.register("./sw.js").catch(console.warn));
}
